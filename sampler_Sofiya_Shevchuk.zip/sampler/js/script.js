document.getElementById("primersonido").onclick = playPauseAudio;


function playPauseAudio() {
    //document.getElementById("musica").muted = false;


    if (document.getElementById("musica").paused) {
        document.getElementById("musica").play();
        document.getElementById("video").play();
  

    } else {

        document.getElementById("musica").pause();
        document.getElementById("video").pause();


    }
}



document.getElementById("segundosonido").onclick = playPauseAudio2;


function playPauseAudio2() {
    //document.getElementById("musica").muted = false;


    if (document.getElementById("musica2").paused) {
        document.getElementById("musica2").play();
        document.getElementById("video").play();


    } else {

        document.getElementById("musica2").pause();
        document.getElementById("video").pause();

    }
}


document.getElementById("tercersonido").onclick = playPauseAudio3;


function playPauseAudio3() {
    //document.getElementById("musica").muted = false;


    if (document.getElementById("musica3").paused) {
        document.getElementById("musica3").play();
         document.getElementById("video").play();


    } else {

        document.getElementById("musica3").pause();
           document.getElementById("video").pause();

    }
}


document.getElementById("cuartosonido").onclick = playPauseAudio4;


function playPauseAudio4() {
    //document.getElementById("musica").muted = false;


    if (document.getElementById("musica4").paused) {
        document.getElementById("musica4").play();
          document.getElementById("video").play();
      

    } else {

        document.getElementById("musica4").pause();
         document.getElementById("video").pause();

 
    }
}

document.getElementById("5sonido").onclick = playPauseAudio5;


function playPauseAudio5() {
    //document.getElementById("musica").muted = false;


    if (document.getElementById("musica5").paused) {
        document.getElementById("musica5").play();
        document.getElementById("video").play();
      

    } else {

        document.getElementById("musica5").pause();
        document.getElementById("video").pause();
 
    }
}


document.getElementById("6sonido").onclick = playPauseAudio6;


function playPauseAudio6() {
    //document.getElementById("musica").muted = false;


    if (document.getElementById("musica6").paused) {
        document.getElementById("musica6").play();
        document.getElementById("video").play();
      

    } else {

        document.getElementById("musica6").pause();
         document.getElementById("video").pause();
 
    }
}

document.getElementById("7sonido").onclick = playPauseAudio7;


function playPauseAudio7() {
    //document.getElementById("musica").muted = false;


    if (document.getElementById("musica7").paused) {
        document.getElementById("musica7").play();
         document.getElementById("video").play();
      

    } else {

        document.getElementById("musica7").pause();
         document.getElementById("video").pause();
 
    }
}

document.getElementById("8sonido").onclick = playPauseAudio8;


function playPauseAudio8() {
    //document.getElementById("musica").muted = false;


    if (document.getElementById("musica8").paused) {
        document.getElementById("musica8").play();
          document.getElementById("video").play();
      

    } else {

        document.getElementById("musica8").pause();
         document.getElementById("video").pause();
 
    }
}






//quant carreguem la pagina assignem a l'slider el valor que tingui el volum

document.getElementById("sliderVol").value = document.getElementById("musica").volume;


//Fem que quan es toqui l'slider s'executi la funció canviaVolum

document.getElementById("sliderVol").oninput = canviaVolum;


function canviaVolum() {

    document.getElementById("musica").volume =
        document.getElementById("sliderVol").value;

}




//quant carreguem la pagina assignem a l'slider el valor que tingui el volum

document.getElementById("sliderVol2").value = document.getElementById("musica2").volume;


//Fem que quan es toqui l'slider s'executi la funció canviaVolum

document.getElementById("sliderVol2").oninput = canviaVolum2;


function canviaVolum2() {

    document.getElementById("musica2").volume =
        document.getElementById("sliderVol2").value;

}


//quant carreguem la pagina assignem a l'slider el valor que tingui el volum

document.getElementById("sliderVol3").value = document.getElementById("musica3").volume;


//Fem que quan es toqui l'slider s'executi la funció canviaVolum

document.getElementById("sliderVol3").oninput = canviaVolum3;


function canviaVolum3() {

    document.getElementById("musica3").volume =
        document.getElementById("sliderVol3").value;

}


document.getElementById("sliderVol4").value = document.getElementById("musica4").volume;


//Fem que quan es toqui l'slider s'executi la funció canviaVolum

document.getElementById("sliderVol4").oninput = canviaVolum4;


function canviaVolum4() {

    document.getElementById("musica4").volume =
        document.getElementById("sliderVol4").value;

}

document.getElementById("sliderVol5").value = document.getElementById("musica5").volume;

document.getElementById("sliderVol5").oninput = canviaVolum5;


function canviaVolum5() {

    document.getElementById("musica5").volume =
        document.getElementById("sliderVol5").value;

}

document.getElementById("sliderVol6").value = document.getElementById("musica6").volume;

document.getElementById("sliderVol6").oninput = canviaVolum6;


function canviaVolum6() {

    document.getElementById("musica6").volume =
        document.getElementById("sliderVol6").value;

}

document.getElementById("sliderVol7").value = document.getElementById("musica7").volume;

document.getElementById("sliderVol7").oninput = canviaVolum7;


function canviaVolum7() {

    document.getElementById("musica7").volume =
        document.getElementById("sliderVol7").value;

}

document.getElementById("sliderVol8").value = document.getElementById("musica8").volume;

document.getElementById("sliderVol8").oninput = canviaVolum8;


function canviaVolum8() {

    document.getElementById("musica8").volume =
        document.getElementById("sliderVol8").value;

}












document.getElementById("sliderTime").max =   document.getElementById("musica").duration;

document.getElementById("sliderTime").onimput = canviaTemps;


function canviaTemps() {

    //assignem el valor de slider al temps de reproducció 
    
    document.getElementById("musica").currentTime =
        document.getElementById("sliderTime").value;

}
